import React, { useState } from "react";
import AccessDeniedBanner from "../components/AccessDeniedBanner";
import NotificationDropdown from "../components/NotificationDropdown";
import { useLocation, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { io } from "socket.io-client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  LayoutDashboard, Factory, Settings, CalendarDays, Users, LogOut,
  Package, Tag, Store, ShoppingCart, GanttChartSquare, Wrench,
  Clock, ClipboardList, ClipboardCheck, Menu, ChevronLeft, ChevronRight,
  Hammer, Warehouse, Layers, BarChart2, FileSpreadsheet, CheckSquare, Camera
} from "lucide-react";
import { DateTime } from "luxon";
import { canShowMenu } from "../constants/permissions";

const menuItems = [
  { type: "subheader", text: "Sản xuất" },
  { text: "Bảng điều khiển", icon: LayoutDashboard, path: "/", permission: "dashboard" },
  { text: "Đơn hàng", icon: ShoppingCart, path: "/orders", permission: "orders" },
  { text: "Lập kế hoạch", icon: CalendarDays, path: "/planning", permission: "planning" },
  { text: "Timeline", icon: GanttChartSquare, path: "/schedule", permission: "schedule" },
  { text: "Phiếu SX hàng ngày", icon: ClipboardList, path: "/daily-tickets", permission: "daily_tickets" },
  { text: "Duyệt phiếu SX", icon: CheckSquare, path: "/daily-tickets/approval", permission: "daily_tickets" },
  { text: "Nhập sản lượng", icon: ClipboardCheck, path: "/production-output", permission: "production_output" },
  { text: "Phiếu gia công", icon: Package, path: "/outsourcing", permission: "outsourcing" },
  { text: "Thông tin Kho", icon: Warehouse, path: "/warehouse", permission: "warehouse" },
  { text: "Tồn kho BTP & TP", icon: Layers, path: "/product-inventory", permission: "product_inventory" },
  { text: "Báo cáo KH vs TT", icon: BarChart2, path: "/plan-vs-actual", permission: "plan_vs_actual" },
  { type: "subheader", text: "Dữ liệu gốc" },
  { text: "Khách hàng", icon: Store, path: "/customers", permission: "customers" },
  { text: "Nhà cung cấp", icon: Store, path: "/suppliers", permission: "suppliers" },
  { text: "Nhà máy", icon: Factory, path: "/factories", permission: "factories" },
  { text: "Máy móc", icon: Wrench, path: "/machines", permission: "machines" },
  { text: "Nhóm mã hàng", icon: Tag, path: "/product-groups", permission: "product_groups" },
  { text: "Mã hàng", icon: Package, path: "/products", permission: "products" },
  { text: "Công đoạn", icon: Settings, path: "/operations", permission: "operations" },
  { text: "Import Excel", icon: FileSpreadsheet, path: "/import", permission: "import_excel" },
  { type: "subheader", text: "Hệ thống" },
  { text: "Chấm công", icon: Clock, path: "/attendance", permission: "attendance" },
  { text: "Quản lý chấm công", icon: Clock, path: "/attendance/management", permission: "attendance_management" },
  { text: "Quản lý công nhân", icon: Users, path: "/workers", permission: "workers" },
  { text: "Người dùng & Quyền", icon: Users, path: "/users", permission: "users" },
  { text: "Snapshot", icon: Camera, path: "/orders/product-snapshots", permission: "orders" },
  { text: "Cài đặt hệ thống", icon: Settings, path: "/settings", permission: "settings" },
];

// CSS vars as JS constants
const C = {
  surface:  'rgb(var(--surface))',
  surface2: 'rgb(var(--surface-2))',
  border:   'rgb(var(--border))',
  text:     'rgb(var(--text))',
  text2:    'rgb(var(--text-2))',
  text3:    'rgb(var(--text-3))',
  text4:    'rgb(var(--text-4))',
  blue:     'rgb(var(--blue))',
  blueL:    'rgb(var(--blue-light))',
  red:      'rgb(var(--red))',
  redL:     'rgb(var(--red-light))',
};

function NavItem({ item, isActive, isCollapsed, onClick }) {
  const Icon = item.icon;
  const btn = (
    <button
      onClick={onClick}
      style={{
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: isCollapsed ? '7px' : '7px 10px',
        borderRadius: 6,
        fontSize: 13,
        fontWeight: isActive ? 500 : 400,
        color: isActive ? C.blue : C.text3,
        background: isActive ? C.blueL : 'transparent',
        border: 'none',
        cursor: 'pointer',
        transition: 'all 0.1s',
        justifyContent: isCollapsed ? 'center' : 'flex-start',
        textAlign: 'left',
      }}
      onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = C.surface2; }}
      onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
    >
      <Icon style={{ width: 15, height: 15, flexShrink: 0, color: isActive ? C.blue : C.text4 }} strokeWidth={isActive ? 2.2 : 1.8} />
      {!isCollapsed && <span style={{ truncate: true, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.text}</span>}
    </button>
  );

  if (isCollapsed) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>{btn}</TooltipTrigger>
        <TooltipContent side="right">{item.text}</TooltipContent>
      </Tooltip>
    );
  }
  return btn;
}

function SidebarContent({ isCollapsed, user, allowedMenus, navigate, location, handleLogout }) {
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.surface, borderRight: `1px solid ${C.border}` }}>
      {/* Brand */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        height: 56, padding: isCollapsed ? '0 14px' : '0 16px',
        borderBottom: `1px solid ${C.border}`,
        justifyContent: isCollapsed ? 'center' : 'flex-start',
        flexShrink: 0,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 7,
          background: C.blue,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <Hammer style={{ width: 14, height: 14, color: '#fff' }} strokeWidth={2.2} />
        </div>
        {!isCollapsed && (
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.text, letterSpacing: '-0.02em', lineHeight: 1.2 }}>Prosimex</div>
            <div style={{ fontSize: 10, color: C.text4, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase' }}>MES Platform</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 8px' }}>
        {allowedMenus.map((item, i) => {
          if (item.type === "subheader") {
            return !isCollapsed ? (
              <div key={i} style={{ fontSize: 10, fontWeight: 600, color: C.text4, textTransform: 'uppercase', letterSpacing: '0.07em', padding: '14px 10px 4px' }}>
                {item.text}
              </div>
            ) : (
              <div key={i} style={{ height: 1, background: C.border, margin: '8px 4px' }} />
            );
          }
          return (
            <NavItem
              key={item.path}
              item={item}
              isActive={location.pathname === item.path}
              isCollapsed={isCollapsed}
              onClick={() => navigate(item.path)}
            />
          );
        })}
      </nav>

      {/* User */}
      <div style={{ borderTop: `1px solid ${C.border}`, padding: '8px', flexShrink: 0 }}>
        <button
          onClick={() => navigate("/profile")}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 8,
            padding: '8px', borderRadius: 6, cursor: 'pointer',
            background: 'transparent', border: 'none', textAlign: 'left',
            justifyContent: isCollapsed ? 'center' : 'flex-start',
          }}
          onMouseEnter={e => e.currentTarget.style.background = C.surface2}
          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          className="group"
        >
          <div style={{
            width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
            background: C.blueL, border: `1px solid rgb(var(--blue-border))`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: C.blue }}>
              {user?.username?.[0]?.toUpperCase()}
            </span>
          </div>
          {!isCollapsed && (
            <>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: C.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {user?.full_name || user?.username}
                </div>
                <div style={{ fontSize: 10, color: C.text4 }}>{user?.role}</div>
              </div>
              <button
                onClick={e => { e.stopPropagation(); handleLogout(); }}
                style={{ padding: 4, borderRadius: 4, color: C.text4, background: 'none', border: 'none', cursor: 'pointer', opacity: 0, transition: 'opacity 0.15s' }}
                onMouseEnter={e => { e.currentTarget.style.color = C.red; e.currentTarget.style.background = C.redL; e.currentTarget.style.opacity = 1; }}
                onMouseLeave={e => { e.currentTarget.style.color = C.text4; e.currentTarget.style.background = 'none'; }}
                className="group-hover:opacity-100"
              >
                <LogOut style={{ width: 13, height: 13 }} />
              </button>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

function LiveClock() {
  const [now, setNow] = useState(DateTime.now());
  React.useEffect(() => {
    const t = setInterval(() => setNow(DateTime.now()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.text3 }}>
      <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'rgb(var(--green))', flexShrink: 0 }} />
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>
        {now.setLocale('vi-VN').toFormat('dd/MM/yyyy')}
      </span>
      <span style={{ color: C.text4 }}>·</span>
      <span style={{ fontWeight: 600, color: C.text2, fontVariantNumeric: 'tabular-nums', fontFamily: 'monospace' }}>
        {now.toFormat('HH:mm:ss')}
      </span>
    </div>
  );
}

export default function MainLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const queryClient = useQueryClient();

  React.useEffect(() => {
    if (!user) return;
    const token = localStorage.getItem('token');
    const socket = io(import.meta.env.VITE_API_URL, { auth: { token } });
    socket.on('new_pending_ticket', (data) => {
      toast.info(data.message, { duration: 8000, action: { label: "Xem ngay", onClick: () => navigate("/daily-tickets/approval") } });
      queryClient.invalidateQueries(["daily-tickets"]);
      queryClient.invalidateQueries(["notifications"]);
    });
    return () => socket.disconnect();
  }, [user, navigate, queryClient]);

  const handleLogout = () => { logout(); navigate("/login"); };

  const allowedMenus = menuItems.filter((item, index) => {
    if (item.type === "subheader") {
      const next = menuItems.slice(index + 1);
      const end = next.findIndex(i => i.type === "subheader");
      const section = end === -1 ? next : next.slice(0, end);
      return section.some(i => canShowMenu(user, i.menuPermission || i.permission));
    }
    return canShowMenu(user, item.menuPermission || item.permission);
  });

  const currentPage = allowedMenus.find(m => m.path === location.pathname);
  const sidebarW = isCollapsed ? 52 : 224;

  return (
    <div style={{ display: 'flex', height: '100vh', background: 'rgb(var(--bg))', overflow: 'hidden' }}>
      {/* Desktop sidebar */}
      <aside style={{ width: sidebarW, flexShrink: 0, transition: 'width 0.2s ease', overflow: 'hidden', display: 'none' }} className="sm:block">
        <SidebarContent isCollapsed={isCollapsed} user={user} allowedMenus={allowedMenus} navigate={navigate} location={location} handleLogout={handleLogout} />
      </aside>
      <aside style={{ width: sidebarW, flexShrink: 0, transition: 'width 0.2s ease', overflow: 'hidden' }} className="hidden sm:block">
        <SidebarContent isCollapsed={isCollapsed} user={user} allowedMenus={allowedMenus} navigate={navigate} location={location} handleLogout={handleLogout} />
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" style={{ padding: 0, width: 224, background: C.surface, border: 'none' }}>
          <SidebarContent isCollapsed={false} user={user} allowedMenus={allowedMenus} navigate={p => { navigate(p); setMobileOpen(false); }} location={location} handleLogout={handleLogout} />
        </SheetContent>
      </Sheet>

      {/* Main */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {/* Topbar */}
        <header style={{
          height: 56, flexShrink: 0,
          background: C.surface,
          borderBottom: `1px solid ${C.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 20px', gap: 12,
          position: 'sticky', top: 0, zIndex: 20,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button
              onClick={() => setMobileOpen(true)}
              style={{ padding: 6, borderRadius: 6, color: C.text3, background: 'none', border: 'none', cursor: 'pointer', display: 'none' }}
              className="sm:hidden"
            >
              <Menu style={{ width: 16, height: 16 }} />
            </button>
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              style={{ padding: 6, borderRadius: 6, color: C.text3, background: 'none', border: 'none', cursor: 'pointer' }}
              onMouseEnter={e => e.currentTarget.style.background = C.surface2}
              onMouseLeave={e => e.currentTarget.style.background = 'none'}
              className="hidden sm:flex"
            >
              {isCollapsed ? <ChevronRight style={{ width: 15, height: 15 }} /> : <ChevronLeft style={{ width: 15, height: 15 }} />}
            </button>
            <div style={{ width: 1, height: 16, background: C.border }} className="hidden sm:block" />
            <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>
              {currentPage?.text || "Hệ thống điều hành"}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <LiveClock />
            <div style={{ width: 1, height: 16, background: C.border }} />
            <NotificationDropdown />
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={handleLogout}
                  style={{ padding: 6, borderRadius: 6, color: C.text3, background: 'none', border: 'none', cursor: 'pointer' }}
                  onMouseEnter={e => { e.currentTarget.style.color = C.red; e.currentTarget.style.background = C.redL; }}
                  onMouseLeave={e => { e.currentTarget.style.color = C.text3; e.currentTarget.style.background = 'none'; }}
                >
                  <LogOut style={{ width: 15, height: 15 }} />
                </button>
              </TooltipTrigger>
              <TooltipContent>Đăng xuất</TooltipContent>
            </Tooltip>
          </div>
        </header>

        {/* Content */}
        <main style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
          <div className="page-enter">
            <Outlet />
          </div>
        </main>
      </div>

      <AccessDeniedBanner />
    </div>
  );
}
