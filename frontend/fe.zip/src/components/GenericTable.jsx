import React, { useState } from 'react';
import { Pencil, Trash2, Plus, Search, ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';

const C = {
  surface:  'rgb(var(--surface))',
  surface2: 'rgb(var(--surface-2))',
  surface3: 'rgb(var(--surface-3))',
  border:   'rgb(var(--border))',
  borderS:  'rgb(var(--border-strong))',
  text:     'rgb(var(--text))',
  text2:    'rgb(var(--text-2))',
  text3:    'rgb(var(--text-3))',
  text4:    'rgb(var(--text-4))',
  blue:     'rgb(var(--blue))',
  blueL:    'rgb(var(--blue-light))',
  blueB:    'rgb(var(--blue-border))',
  red:      'rgb(var(--red))',
  redL:     'rgb(var(--red-light))',
  redB:     'rgb(var(--red-border))',
};

function SearchBar({ onSearch, initial = "" }) {
  const [val, setVal] = React.useState(initial);
  return (
    <form onSubmit={e => { e.preventDefault(); onSearch(val); }} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{ position: 'relative' }}>
        <Search style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', width: 13, height: 13, color: C.text4 }} />
        <input
          value={val} onChange={e => setVal(e.target.value)}
          placeholder="Tìm kiếm..."
          style={{
            height: 32, paddingLeft: 28, paddingRight: 10, width: 200,
            background: C.surface, border: `1px solid ${C.borderS}`,
            borderRadius: 6, fontSize: 13, color: C.text, outline: 'none',
          }}
          onFocus={e => { e.target.style.borderColor = C.blue; e.target.style.boxShadow = `0 0 0 3px rgb(var(--blue) / 0.1)`; }}
          onBlur={e => { e.target.style.borderColor = C.borderS; e.target.style.boxShadow = 'none'; }}
        />
      </div>
      <button type="submit" style={{ height: 32, padding: '0 12px', background: C.blue, color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 500, cursor: 'pointer' }}>
        Lọc
      </button>
      {val && (
        <button type="button" onClick={() => { setVal(""); onSearch(""); }}
          style={{ height: 32, width: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', background: C.surface, border: `1px solid ${C.borderS}`, borderRadius: 6, cursor: 'pointer', color: C.text4 }}
          onMouseEnter={e => { e.currentTarget.style.color = C.red; e.currentTarget.style.borderColor = C.redB; }}
          onMouseLeave={e => { e.currentTarget.style.color = C.text4; e.currentTarget.style.borderColor = C.borderS; }}
        >
          <RotateCcw style={{ width: 12, height: 12 }} />
        </button>
      )}
    </form>
  );
}

export default function GenericTable({
  title, data = [], columns = [], isLoading, error,
  onAdd, onEdit, onDelete, onBulkDelete,
  isServerSide = false, totalItems = 0, page = 1, pageSize = 10,
  onPageChange, onPageSizeChange, onSearchChange, renderActions,
  maxHeight = "calc(100vh - 280px)",
  selectedRows, onSelectionChange, freezeFirstCols = false,
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [internalSelected, setInternalSelected] = useState([]);
  const [clientPage, setClientPage] = useState(1);
  const [clientPageSize, setClientPageSize] = useState(10);

  const isControlled = selectedRows !== undefined && onSelectionChange !== undefined;
  const selected = isControlled ? selectedRows : internalSelected;
  const setSelected = v => isControlled ? onSelectionChange(typeof v === 'function' ? v(selected) : v) : setInternalSelected(v);

  const filtered = isServerSide ? data : (data?.filter(row =>
    Object.values(row).some(v => String(v ?? '').toLowerCase().includes(searchTerm.toLowerCase()))
  ) ?? []);

  const effPage     = isServerSide ? page : clientPage;
  const effPageSize = isServerSide ? pageSize : clientPageSize;
  const effTotal    = isServerSide ? totalItems : filtered.length;
  const totalPages  = Math.ceil(effTotal / effPageSize);
  const startIdx    = (effPage - 1) * effPageSize;
  const rows        = isServerSide ? data : filtered.slice(startIdx, startIdx + effPageSize);

  const allSel  = rows.length > 0 && rows.every(r => selected.includes(r.id));
  const someSel = rows.some(r => selected.includes(r.id)) && !allSel;

  const handleSelectAll = e => {
    const ids = rows.map(r => r.id);
    setSelected(prev => e.target.checked ? [...new Set([...prev, ...ids])] : prev.filter(id => !ids.includes(id)));
  };
  const handleSelect = (e, id) => {
    e.stopPropagation();
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const handleSearch = v => {
    setSearchTerm(v);
    if (isServerSide) onSearchChange?.(v); else setClientPage(1);
  };
  const handlePage = p => isServerSide ? onPageChange?.(p) : setClientPage(p);
  const handlePageSize = s => { if (isServerSide) onPageSizeChange?.(s); else { setClientPageSize(s); setClientPage(1); } };

  if (error) return (
    <div style={{ padding: '12px 16px', background: C.redL, border: `1px solid ${C.redB}`, borderRadius: 8, color: C.red, fontSize: 13 }}>
      ⚠ {error.message || 'Lỗi khi tải dữ liệu'}
    </div>
  );

  const headStyle = {
    position: 'sticky', top: 0, zIndex: 10,
    background: C.surface2,
    padding: '9px 14px',
    fontSize: 11, fontWeight: 600, color: C.text3,
    textTransform: 'uppercase', letterSpacing: '0.06em',
    borderBottom: `1px solid ${C.border}`,
    whiteSpace: 'nowrap',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {/* Toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          {typeof title === 'string'
            ? <h2 style={{ fontSize: 15, fontWeight: 600, color: C.text }}>{title}</h2>
            : title}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          {(onSearchChange !== undefined || !isServerSide) && <SearchBar onSearch={handleSearch} initial={searchTerm} />}
          {onBulkDelete && selected.length > 0 && (
            <button
              onClick={() => { onBulkDelete(selected); setSelected([]); }}
              style={{ height: 32, padding: '0 12px', background: C.redL, color: C.red, border: `1px solid ${C.redB}`, borderRadius: 6, fontSize: 12, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}
            >
              <Trash2 style={{ width: 12, height: 12 }} /> Xóa {selected.length} mục
            </button>
          )}
          {onAdd && (
            <button
              onClick={onAdd}
              style={{ height: 32, padding: '0 14px', background: C.blue, color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgb(var(--blue-hover))'}
              onMouseLeave={e => e.currentTarget.style.background = C.blue}
            >
              <Plus style={{ width: 13, height: 13 }} /> Thêm mới
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto', overflowY: 'auto', maxHeight }}>
          <table style={{ width: '100%', borderCollapse: freezeFirstCols ? 'separate' : 'collapse', borderSpacing: 0, fontSize: 13 }}>
            <thead>
              <tr>
                {onBulkDelete && (
                  <th style={{ ...headStyle, width: 40, textAlign: 'center', left: freezeFirstCols ? 0 : undefined, position: freezeFirstCols ? 'sticky' : 'sticky', zIndex: freezeFirstCols ? 30 : 10, borderRight: freezeFirstCols ? `1px solid ${C.border}` : undefined }}>
                    <input type="checkbox" checked={allSel} ref={el => el && (el.indeterminate = someSel)} onChange={handleSelectAll}
                      style={{ width: 13, height: 13, cursor: 'pointer', accentColor: C.blue }} />
                  </th>
                )}
                <th style={{ ...headStyle, width: 48, textAlign: 'center', left: freezeFirstCols ? (onBulkDelete ? 40 : 0) : undefined, position: 'sticky', zIndex: freezeFirstCols ? 30 : 10, borderRight: freezeFirstCols ? `1px solid ${C.border}` : undefined }}>
                  #
                </th>
                {columns.map(col => (
                  <th key={col.id} style={{
                    ...headStyle,
                    textAlign: col.align || 'left',
                    width: col.width || (col.minWidth ? `${col.minWidth}px` : 'auto'),
                    minWidth: col.minWidth ? `${col.minWidth}px` : undefined,
                    left: col.isSticky ? col.stickyLeft : undefined,
                    position: col.isSticky ? 'sticky' : 'sticky',
                    zIndex: col.isSticky ? 30 : 10,
                    borderRight: col.isSticky ? `1px solid ${C.border}` : undefined,
                  }}>
                    {col.label}
                  </th>
                ))}
                {(onEdit || onDelete || renderActions) && (
                  <th style={{ ...headStyle, width: 88, textAlign: 'center' }}>Thao tác</th>
                )}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} style={{ borderBottom: `1px solid ${C.border}` }}>
                    {Array.from({ length: (onBulkDelete ? 1 : 0) + 1 + columns.length + (onEdit || onDelete ? 1 : 0) }).map((_, j) => (
                      <td key={j} style={{ padding: '12px 14px' }}>
                        <div style={{ height: 12, borderRadius: 4, background: C.surface2, animation: 'pulse 1.5s infinite' }} />
                      </td>
                    ))}
                  </tr>
                ))
              ) : rows.length === 0 ? (
                <tr>
                  <td colSpan={columns.length + (onBulkDelete ? 3 : 2)} style={{ padding: '48px 24px', textAlign: 'center' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                      <Search style={{ width: 24, height: 24, color: C.text4 }} />
                      <span style={{ fontSize: 13, color: C.text4 }}>Không tìm thấy dữ liệu</span>
                    </div>
                  </td>
                </tr>
              ) : rows.map((row, idx) => {
                const isSel = selected.includes(row.id);
                const rowBg = isSel ? C.blueL : C.surface;
                return (
                  <tr key={row.id ?? idx}
                    style={{ borderBottom: `1px solid ${C.border}`, background: rowBg, transition: 'background 0.1s' }}
                    onMouseEnter={e => { if (!isSel) e.currentTarget.style.background = C.surface2; }}
                    onMouseLeave={e => { e.currentTarget.style.background = isSel ? C.blueL : C.surface; }}
                  >
                    {onBulkDelete && (
                      <td style={{ padding: '0 14px', textAlign: 'center', background: isSel ? C.blueL : C.surface, ...(freezeFirstCols ? { position: 'sticky', left: 0, zIndex: 20, borderRight: `1px solid ${C.border}` } : {}) }}>
                        <input type="checkbox" checked={isSel} onChange={e => handleSelect(e, row.id)}
                          style={{ width: 13, height: 13, cursor: 'pointer', accentColor: C.blue }} />
                      </td>
                    )}
                    <td style={{ padding: '10px 14px', textAlign: 'center', fontSize: 11, fontWeight: 600, color: C.text4, background: isSel ? C.blueL : C.surface, ...(freezeFirstCols ? { position: 'sticky', left: onBulkDelete ? 40 : 0, zIndex: 20, borderRight: `1px solid ${C.border}` } : {}) }}>
                      {String(startIdx + idx + 1).padStart(2, '0')}
                    </td>
                    {columns.map(col => (
                      <td key={col.id} className={col.className} style={{
                        padding: '10px 14px',
                        textAlign: col.align || 'left',
                        color: C.text2,
                        borderRight: `1px solid ${C.border}`,
                        background: col.isSticky ? (isSel ? C.blueL : C.surface) : undefined,
                        ...(col.isSticky ? { position: 'sticky', left: col.stickyLeft, zIndex: 20 } : {}),
                        width: col.width || (col.minWidth ? `${col.minWidth}px` : 'auto'),
                        minWidth: col.minWidth ? `${col.minWidth}px` : undefined,
                      }}>
                        {col.format ? col.format(row[col.id], row) : (row[col.id] ?? '—')}
                      </td>
                    ))}
                    {(onEdit || onDelete || renderActions) && (
                      <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2 }}>
                          {renderActions ? renderActions(row) : (
                            <>
                              {onEdit && (
                                <button onClick={e => { e.stopPropagation(); onEdit(row); }}
                                  style={{ padding: 5, borderRadius: 5, color: C.text4, background: 'none', border: 'none', cursor: 'pointer' }}
                                  onMouseEnter={e => { e.currentTarget.style.color = C.blue; e.currentTarget.style.background = C.blueL; }}
                                  onMouseLeave={e => { e.currentTarget.style.color = C.text4; e.currentTarget.style.background = 'none'; }}
                                  title="Chỉnh sửa"
                                >
                                  <Pencil style={{ width: 13, height: 13 }} />
                                </button>
                              )}
                              {onDelete && (
                                <button onClick={e => { e.stopPropagation(); onDelete(row); }}
                                  style={{ padding: 5, borderRadius: 5, color: C.text4, background: 'none', border: 'none', cursor: 'pointer' }}
                                  onMouseEnter={e => { e.currentTarget.style.color = C.red; e.currentTarget.style.background = C.redL; }}
                                  onMouseLeave={e => { e.currentTarget.style.color = C.text4; e.currentTarget.style.background = 'none'; }}
                                  title="Xóa"
                                >
                                  <Trash2 style={{ width: 13, height: 13 }} />
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div style={{ padding: '10px 16px', borderTop: `1px solid ${C.border}`, background: C.surface2, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <span style={{ fontSize: 12, color: C.text3 }}>
              Tổng: <strong style={{ color: C.text }}>{effTotal}</strong> bản ghi
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 11, color: C.text4 }}>Hiển thị</span>
              <select value={effPageSize} onChange={e => handlePageSize(+e.target.value)}
                style={{ height: 28, padding: '0 6px', background: C.surface, border: `1px solid ${C.borderS}`, borderRadius: 5, fontSize: 12, color: C.text, cursor: 'pointer', outline: 'none' }}>
                {[5, 10, 25, 50, 100].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 12, color: C.text3 }}>
              Trang <strong style={{ color: C.text }}>{effPage}</strong> / {totalPages || 1}
            </span>
            {[
              { Icon: ChevronLeft, disabled: effPage === 1, onClick: () => handlePage(effPage - 1) },
              { Icon: ChevronRight, disabled: effPage >= totalPages, onClick: () => handlePage(effPage + 1) },
            ].map(({ Icon, disabled, onClick }, i) => (
              <button key={i} onClick={onClick} disabled={disabled}
                style={{ width: 28, height: 28, borderRadius: 5, border: `1px solid ${C.borderS}`, background: disabled ? C.surface2 : C.surface, color: disabled ? C.text4 : C.text2, cursor: disabled ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.5 : 1 }}
                onMouseEnter={e => { if (!disabled) e.currentTarget.style.borderColor = C.blue; }}
                onMouseLeave={e => { if (!disabled) e.currentTarget.style.borderColor = C.borderS; }}
              >
                <Icon style={{ width: 13, height: 13 }} />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
