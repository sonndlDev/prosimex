import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { dashboardService } from '../../services/dashboard.service';
import { useAuth } from '../../context/AuthContext';
import { Skeleton } from '@/components/ui/skeleton';
import { ShoppingCart, CalendarDays, Wrench, Users, Activity, UserCheck, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { DateTime } from 'luxon';

const actionColor = (a) => ({ CREATE: 'rgb(var(--green))', DELETE: 'rgb(var(--red))', CLONE: '#7c3aed' }[a] ?? 'rgb(var(--blue))');
const actionLabel = (a) => ({ CREATE: 'Tạo mới', DELETE: 'Xóa', CLONE: 'Sao chép' }[a] ?? 'Cập nhật');
const actionBg    = (a) => ({ CREATE: 'rgb(var(--green-light))', DELETE: 'rgb(var(--red-light))', CLONE: '#f5f3ff' }[a] ?? 'rgb(var(--blue-light))');
const actionBorder= (a) => ({ CREATE: 'rgb(var(--green-border))', DELETE: 'rgb(var(--red-border))', CLONE: '#ddd6fe' }[a] ?? 'rgb(var(--blue-border))');

const entityLabel = (e) => ({
  ProductGroupOperation: 'Công đoạn nhóm SP', ProductionPlan: 'Kế hoạch SX',
  Order: 'Đơn hàng', Product: 'Sản phẩm', Machine: 'Máy móc', Worker: 'Công nhân',
  User: 'Người dùng', Factory: 'Nhà máy', Customer: 'Khách hàng',
  ProductGroup: 'Nhóm sản phẩm', Operation: 'Công đoạn',
  DailyProductionTicket: 'Phiếu SX', OutsourcingTicket: 'Phiếu gia công',
  ProductionPlanDay: 'Chi tiết kế hoạch ngày',
}[e] ?? e);

const STATUS_CFG = {
  DRAFT:       { label: 'Nháp',       color: 'rgb(var(--text-4))' },
  PLANNED:     { label: 'Kế hoạch',   color: 'rgb(var(--blue))' },
  IN_PROGRESS: { label: 'Đang SX',    color: 'rgb(var(--amber))' },
  DONE:        { label: 'Hoàn thành', color: 'rgb(var(--green))' },
  CANCELLED:   { label: 'Đã hủy',     color: 'rgb(var(--red))' },
};

// ── Stat Card ─────────────────────────────────────────────
function StatCard({ title, value, icon: Icon, accent, loading, children }) {
  return (
    <div className="bg-[rgb(var(--surface))] border border-[rgb(var(--border))] rounded-lg p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.06em] text-[rgb(var(--text-4))] mb-2">{title}</p>
          {loading
            ? <Skeleton className="h-8 w-16" />
            : <span className="text-[26px] font-bold text-[rgb(var(--text))] tracking-tight leading-none">{value ?? 0}</span>
          }
          {children && <div className="mt-3">{children}</div>}
        </div>
        <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${accent}18`, border: `1px solid ${accent}30` }}>
          <Icon className="w-4 h-4" style={{ color: accent }} strokeWidth={2} />
        </div>
      </div>
    </div>
  );
}

// ── Section Card ──────────────────────────────────────────
function SectionCard({ icon: Icon, title, action, onAction, children }) {
  return (
    <div className="bg-[rgb(var(--surface))] border border-[rgb(var(--border))] rounded-lg overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[rgb(var(--border))] bg-[rgb(var(--surface-2))]">
        <div className="flex items-center gap-2.5">
          <Icon className="w-4 h-4 text-[rgb(var(--text-3))]" strokeWidth={1.8} />
          <span className="text-[13px] font-semibold text-[rgb(var(--text))]">{title}</span>
        </div>
        {action && (
          <button onClick={onAction} className="text-[12px] text-[rgb(var(--blue))] hover:text-[rgb(var(--blue-hover))] font-medium transition-colors">
            {action}
          </button>
        )}
      </div>
      <div className="px-5 py-1">{children}</div>
    </div>
  );
}

// ── Activity Row ──────────────────────────────────────────
function ActivityRow({ act }) {
  const col = actionColor(act.action);
  return (
    <div className="flex items-start gap-3 py-3 border-b border-[rgb(var(--border))] last:border-0">
      <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: col }} />
      <div className="flex-1 min-w-0">
        <p className="text-[13px] text-[rgb(var(--text-2))] leading-snug">
          <strong className="text-[rgb(var(--text))]">{act.user_name}</strong>{' '}
          <span className="inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded border" style={{ background: actionBg(act.action), color: col, borderColor: actionBorder(act.action) }}>
            {actionLabel(act.action)}
          </span>{' '}
          <span className="text-[rgb(var(--text-3))]">{entityLabel(act.entity)}</span>
          {act.entity_id && <span className="text-[rgb(var(--text-4))] text-[11px]"> #{act.entity_id}</span>}
        </p>
        <p className="text-[11px] text-[rgb(var(--text-4))] mt-0.5">
          {DateTime.fromISO(act.created_at).setLocale('vi-VN').toFormat('dd/MM/yyyy HH:mm:ss')}
        </p>
      </div>
    </div>
  );
}

// ── Activities Modal ──────────────────────────────────────
function ActivitiesModal({ open, onClose }) {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useQuery({
    queryKey: ['dashboardActivities', page],
    queryFn: () => dashboardService.getActivities({ page, limit: 15 }),
    enabled: open, keepPreviousData: true,
  });
  if (!open) return null;
  const totalPages = data?.totalPages ?? 1;
  const pages = () => {
    const t = totalPages;
    if (t <= 5) return Array.from({ length: t }, (_, i) => i + 1);
    if (page <= 3) return [1, 2, 3, 4, 5];
    if (page >= t - 2) return [t - 4, t - 3, t - 2, t - 1, t];
    return [page - 2, page - 1, page, page + 1, page + 2];
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-[2px]" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-[rgb(var(--surface))] border border-[rgb(var(--border))] rounded-xl w-full max-w-lg mx-4 flex flex-col shadow-[0_16px_48px_rgba(0,0,0,0.12)]" style={{ maxHeight: '88vh' }}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-[rgb(var(--border))] bg-[rgb(var(--surface-2))] rounded-t-xl">
          <div className="flex items-center gap-2.5">
            <Activity className="w-4 h-4 text-[rgb(var(--text-3))]" />
            <span className="text-[14px] font-semibold text-[rgb(var(--text))]">Lịch sử hoạt động</span>
            {data?.total != null && <span className="text-[11px] text-[rgb(var(--text-4))]">{data.total.toLocaleString('vi-VN')} bản ghi</span>}
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-md hover:bg-[rgb(var(--surface-3))] flex items-center justify-center text-[rgb(var(--text-3))] transition-colors">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5">
          {isLoading
            ? Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-10 w-full my-2" />)
            : data?.data?.length > 0
              ? data.data.map((act, i) => <ActivityRow key={act.id ?? i} act={act} />)
              : <p className="py-12 text-center text-[13px] text-[rgb(var(--text-4))]">Không có hoạt động nào.</p>
          }
        </div>
        <div className="flex items-center justify-between px-5 py-3 border-t border-[rgb(var(--border))] bg-[rgb(var(--surface-2))] rounded-b-xl">
          <span className="text-[12px] text-[rgb(var(--text-3))]">Trang {page} / {totalPages}</span>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="w-7 h-7 rounded border border-[rgb(var(--border-strong))] flex items-center justify-center text-[rgb(var(--text-3))] hover:bg-[rgb(var(--surface-3))] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            {pages().map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={`w-7 h-7 rounded text-[12px] font-medium transition-colors ${page === p ? 'bg-[rgb(var(--blue))] text-white' : 'border border-[rgb(var(--border-strong))] text-[rgb(var(--text-3))] hover:bg-[rgb(var(--surface-3))]'}`}>
                {p}
              </button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="w-7 h-7 rounded border border-[rgb(var(--border-strong))] flex items-center justify-center text-[rgb(var(--text-3))] hover:bg-[rgb(var(--surface-3))] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Order Status Bar ──────────────────────────────────────
function OrderStatusBar({ ordersByStatus, total, loading }) {
  if (loading) return <Skeleton className="h-1.5 w-full mt-2" />;
  if (!ordersByStatus || total === 0) return null;
  return (
    <div className="mt-2">
      <div className="flex h-1.5 rounded-full overflow-hidden gap-px">
        {Object.entries(STATUS_CFG).map(([key, cfg]) => {
          const pct = total > 0 ? ((ordersByStatus[key] || 0) / total) * 100 : 0;
          if (pct === 0) return null;
          return <div key={key} title={`${cfg.label}: ${ordersByStatus[key]}`} style={{ background: cfg.color, width: `${pct}%` }} />;
        })}
      </div>
      <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1.5">
        {Object.entries(STATUS_CFG).map(([key, cfg]) => {
          const count = ordersByStatus[key] || 0;
          if (!count) return null;
          return (
            <div key={key} className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.color }} />
              <span className="text-[10px] text-[rgb(var(--text-4))]">{cfg.label}: <strong className="text-[rgb(var(--text-3))]">{count}</strong></span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Attendance Panel ──────────────────────────────────────
function AttendancePanel({ data, myAttendance, loading }) {
  const navigate = useNavigate();
  if (loading) return <Skeleton className="h-14 w-full mt-2" />;
  if (!data) return null;
  const hasIn  = !!myAttendance;
  const hasOut = !!(myAttendance?.check_out_time);
  const accent = hasOut ? 'rgb(var(--green))' : hasIn ? 'rgb(var(--blue))' : 'rgb(var(--amber))';
  const accentBg = hasOut ? 'rgb(var(--green-light))' : hasIn ? 'rgb(var(--blue-light))' : 'rgb(var(--amber-light))';
  const accentBorder = hasOut ? 'rgb(var(--green-border))' : hasIn ? 'rgb(var(--blue-border))' : 'rgb(var(--amber-border))';
  const label = hasOut
    ? `Check-in ${DateTime.fromISO(myAttendance.check_in_time).toFormat('HH:mm')} · Check-out ${DateTime.fromISO(myAttendance.check_out_time).toFormat('HH:mm')}`
    : hasIn ? `Check-in lúc ${DateTime.fromISO(myAttendance.check_in_time).toFormat('HH:mm')}`
    : 'Bạn chưa check-in hôm nay';
  return (
    <div className="flex items-center justify-between p-3 rounded-lg mt-2 border" style={{ background: accentBg, borderColor: accentBorder }}>
      <div className="flex items-center gap-2.5">
        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: accent }} />
        <div>
          <p className="text-[13px] font-medium text-[rgb(var(--text))]">{label}</p>
          <p className="text-[11px] text-[rgb(var(--text-3))] mt-0.5">Hôm nay · {DateTime.now().setLocale('vi-VN').toFormat('dd/MM/yyyy')}</p>
        </div>
      </div>
      <button onClick={() => navigate('/attendance')}
        className="text-[12px] font-semibold px-3 py-1.5 rounded-md text-white flex-shrink-0 transition-colors"
        style={{ background: accent }}>
        {hasOut ? 'Xem' : hasIn ? 'Check-out →' : 'Check-in →'}
      </button>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────
export default function DashboardPage() {
  const { user } = useAuth();
  const [showModal, setShowModal] = useState(false);

  const { data: metrics, isLoading } = useQuery({
    queryKey: ['dashboardMetrics'],
    queryFn: dashboardService.getMetrics,
    refetchInterval: 15000,
  });

  return (
    <div className="space-y-4">
      <ActivitiesModal open={showModal} onClose={() => setShowModal(false)} />

      {/* Header */}
      <div>
        <h2 className="text-[18px] font-semibold text-[rgb(var(--text))] tracking-tight">
          Xin chào, {user?.username} 👋
        </h2>
        <p className="text-[13px] text-[rgb(var(--text-3))] mt-1">Chào mừng bạn quay trở lại. Chúc bạn một ngày làm việc hiệu quả!</p>
      </div>

      {/* Attendance */}
      <SectionCard icon={UserCheck} title="Điểm danh hôm nay">
        <AttendancePanel data={metrics?.todayAttendance} myAttendance={metrics?.myAttendance} loading={isLoading} />
      </SectionCard>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard title="Đơn hàng" value={metrics?.totalOrders} icon={ShoppingCart} accent="rgb(var(--blue))" loading={isLoading}>
          <OrderStatusBar ordersByStatus={metrics?.ordersByStatus} total={metrics?.totalOrders} loading={isLoading} />
        </StatCard>
        <StatCard title="Kế hoạch đang chạy" value={metrics?.activePlans} icon={CalendarDays} accent="#7c3aed" loading={isLoading} />
        <StatCard title="Hiệu suất máy" value={metrics?.activeMachines != null ? `${metrics.activeMachines}%` : '0%'} icon={Wrench} accent="rgb(var(--green))" loading={isLoading} />
        <StatCard title="Người dùng" value={metrics?.activeUsers} icon={Users} accent="rgb(var(--amber))" loading={isLoading} />
      </div>

      {/* Activities */}
      <SectionCard icon={Activity} title="Hoạt động mới nhất" action="Xem tất cả" onAction={() => setShowModal(true)}>
        <div>
          {isLoading
            ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full my-2" />)
            : metrics?.activities?.length > 0
              ? metrics.activities.map((act, i) => <ActivityRow key={i} act={act} />)
              : <p className="py-8 text-center text-[13px] text-[rgb(var(--text-4))]">Hiện không có hoạt động nào gần đây.</p>
          }
        </div>
      </SectionCard>
    </div>
  );
}
