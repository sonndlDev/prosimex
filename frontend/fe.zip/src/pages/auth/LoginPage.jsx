import React, { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Hammer, Eye, EyeOff, Loader2 } from "lucide-react";

export default function LoginPage() {
  const { control, handleSubmit } = useForm({ defaultValues: { username: "", password: "" } });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    setError(""); setLoading(true);
    try { await login(data.username, data.password); navigate("/"); }
    catch (err) { setError(err.response?.data?.message || "Tên đăng nhập hoặc mật khẩu không đúng."); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'rgb(var(--bg))', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 380 }}>
        {/* Brand */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 10, background: 'rgb(var(--blue))',
            display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px',
          }}>
            <Hammer style={{ width: 22, height: 22, color: '#fff' }} strokeWidth={2.2} />
          </div>
          <h1 style={{ fontSize: 20, fontWeight: 700, color: 'rgb(var(--text))', letterSpacing: '-0.02em' }}>
            Prosimex MES
          </h1>
          <p style={{ fontSize: 13, color: 'rgb(var(--text-3))', marginTop: 4 }}>
            Hệ thống điều hành sản xuất
          </p>
        </div>

        {/* Card */}
        <div style={{
          background: 'rgb(var(--surface))',
          border: '1px solid rgb(var(--border))',
          borderRadius: 10,
          padding: 24,
          boxShadow: '0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)',
        }}>
          {error && (
            <div style={{
              background: 'rgb(var(--red-light))', border: '1px solid rgb(var(--red-border))',
              borderRadius: 6, padding: '10px 12px', marginBottom: 16,
              fontSize: 13, color: 'rgb(var(--red))',
            }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: 'rgb(var(--text-2))', marginBottom: 6 }}>
                Tên đăng nhập
              </label>
              <Controller name="username" control={control} render={({ field }) => (
                <input {...field} placeholder="Nhập tên đăng nhập" disabled={loading} required autoComplete="username"
                  className="field" style={{ width: '100%', height: 38 }} />
              )} />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: 'rgb(var(--text-2))', marginBottom: 6 }}>
                Mật khẩu
              </label>
              <div style={{ position: 'relative' }}>
                <Controller name="password" control={control} render={({ field }) => (
                  <input {...field} type={showPw ? "text" : "password"} placeholder="Nhập mật khẩu"
                    disabled={loading} required autoComplete="current-password"
                    className="field" style={{ width: '100%', height: 38, paddingRight: 36 }} />
                )} />
                <button type="button" tabIndex={-1} onClick={() => setShowPw(!showPw)}
                  style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: 'rgb(var(--text-4))', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
                  {showPw ? <EyeOff style={{ width: 15, height: 15 }} /> : <Eye style={{ width: 15, height: 15 }} />}
                </button>
              </div>
            </div>

            <button
              type="submit" disabled={loading}
              style={{
                width: '100%', height: 38, marginTop: 4,
                background: loading ? 'rgb(var(--blue) / 0.7)' : 'rgb(var(--blue))',
                color: '#fff', border: 'none', borderRadius: 6,
                fontSize: 13, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                transition: 'background 0.15s',
              }}
              onMouseEnter={e => { if (!loading) e.currentTarget.style.background = 'rgb(var(--blue-hover))'; }}
              onMouseLeave={e => { if (!loading) e.currentTarget.style.background = 'rgb(var(--blue))'; }}
            >
              {loading ? <><Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} />Đang đăng nhập...</> : "Đăng nhập"}
            </button>
          </form>
        </div>

        <p style={{ textAlign: 'center', fontSize: 11, color: 'rgb(var(--text-4))', marginTop: 20 }}>
          © 2026 Prosimex Corporation
        </p>
      </div>
    </div>
  );
}
